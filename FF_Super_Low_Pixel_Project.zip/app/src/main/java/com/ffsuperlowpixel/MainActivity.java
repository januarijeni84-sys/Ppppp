package com.ffsuperlowpixel;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 30, 35)));
        return b;
    }

    void add(View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        root.addView(v, p);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,16,16));
        getWindow().setNavigationBarColor(Color.rgb(16,16,16));

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(24));
        root.setBackgroundColor(Color.rgb(18,18,18));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("FF SUPER LOW PIXEL", 25, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        add(title);

        TextView subtitle = text("PANEL PENGATURAN • OPPO A53", 13, Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        add(subtitle);

        TextView note = text("Aplikasi pendamping. Android tidak mengizinkan aplikasi ini memaksa perubahan tekstur atau resolusi internal Free Fire. Gunakan pengaturan resmi di dalam game.", 14, Color.WHITE);
        note.setPadding(dp(14),dp(14),dp(14),dp(14));
        note.setBackgroundColor(Color.rgb(42,42,42));
        add(note);

        status = text("PROFIL: BELUM DIPILIH", 16, Color.rgb(255,190,80));
        status.setGravity(Gravity.CENTER);
        add(status);

        Button low = button("AKTIFKAN PROFIL SUPER LOW");
        low.setOnClickListener(v -> {
            status.setText("PROFIL: SUPER LOW DIPILIH");
            Toast.makeText(this, "Gunakan setelan grafis Smooth dan FPS sesuai opsi resmi game.", Toast.LENGTH_LONG).show();
        });
        add(low);

        Button pixel = button("PIXEL MODE • PRATINJAU");
        pixel.setOnClickListener(v -> {
            status.setText("MODE: PRATINJAU PIXEL (DALAM APLIKASI)");
            Toast.makeText(this, "Efek pixel hanya untuk pratinjau aplikasi, bukan Free Fire.", Toast.LENGTH_LONG).show();
        });
        add(pixel);

        Button display = button("BUKA PENGATURAN LAYAR ANDROID");
        display.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Pengaturan layar tidak tersedia.", Toast.LENGTH_SHORT).show(); }
        });
        add(display);

        Button reset = button("RESET PROFIL");
        reset.setOnClickListener(v -> status.setText("PROFIL: BELUM DIPILIH"));
        add(reset);

        TextView tips = text("TIPS OPPO A53\n• Tutup aplikasi latar belakang sebelum bermain.\n• Aktifkan mode performa/Game Space jika tersedia.\n• Di Free Fire, pilih grafis Smooth dan matikan efek yang tidak diperlukan.\n• Hindari aplikasi pihak ketiga yang meminta akses root atau mengubah file game.", 14, Color.LTGRAY);
        tips.setPadding(dp(4),dp(8),dp(4),dp(8));
        add(tips);

        TextView footer = text("Versi 1.0 • Tidak berafiliasi dengan Garena", 11, Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        add(footer);
    }
}
